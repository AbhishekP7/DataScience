#This is a simple python package with basic necessary file structure
